package test

import (
  "github.com/gruntwork-io/terratest/modules/terraform"
  "testing"
  "github.com/stretchr/testify/assert"
)

/*func TestSqlMI(t *testing.T) {
	// t.Parallel()
  
	  terraformOptions := &terraform.Options{
  
		
		TerraformDir : "./Fixtures/AzureSqlManagedInstance",
	  
	   Vars: map[string]interface{}{
	 
		"sqlmi_rgName"                    : "rg-ads-eus2-entbusops-dev-ihub-001",
		"sqlmi_templatename"              : "sqlmi-ads-eus2-entbusops-dev-ihub-template-001testing",
		"sqlmi_instancename"              : "sqlmi-ads-eus2-entbusops-dev-ihub-001testing",
		"sqlmi_adminLogin"                : "sqlmi-ads-admin-dev",
		"sqlmi_key_vault_name"            : "kvadseus2entbusopsihub1",
		"sqlmi_keyvault_secret_name"      : "sqlmi-adminPassword",
		"sqlmi_location"                  : "eastus2",
		"sqlmi_vnetName"                  : "vnet-ads-eus2-entbusops-dev-ihub-001",
		"sqlmi_snetName"                  : "sn-ads-eus2-entbusops-dev-ihub-sql-001",
		"sqlmi_sku_Name"                  : "GP_Gen5",
		"sqlmi_sqlInstancevCores"         : "8",
		"sqlmi_storageSizeInGB"           : "128",
		"sqlmi_sqlInstancelicenseType"    : "LicenseIncluded",
		"sqlmi_IdentityType"              : "SystemAssigned",
		"sqlmi_collation"                 : "SQL_Latin1_General_CP1_CI_AS",
		"sqlmi_minimalTlsVersion"         : "1.2",
		"sqlmi_publicDataEndpointEnabled" : "false", //Set as string but to be converted to bool in ARM template
		"sqlmi_proxyOverride"             : "Proxy",
		"sqlmi_storageAccountType"        : "LRS",
		"sqlmi_deploymentMode"            : "Incremental",
	},
  }
  
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
	  
	  output1 := terraform.Output(t, terraformOptions, "sqlmi_template_name")
	  assert.Equal(t, "sqlmi-ads-eus2-entbusops-dev-ihub-template-001testing",output1)
	  output2 := terraform.Output(t, terraformOptions, "sqlmi_name")
		assert.Equal(t, "sqlmi-ads-eus2-entbusops-dev-ihub-001testing",output2)
  
  }*/

  func TestRedisCache(t *testing.T) {
	// t.Parallel()
  
	  terraformOptions := &terraform.Options{
  
		
		TerraformDir : "./Fixtures/RedisCache",
	  
	   Vars: map[string]interface{}{
	 
		"redisCacheName"                  : "arc-ads-eus2-entbusops-dev-ihub-001test",
		"region"                          : "East US 2",
		"rgName"                          : "rg-ads-eus2-entbusops-dev-ihub-001",                    
		"arc_capacity"                    : 1,
		"family"                          : "C",
		"redis_sku_name"                  : "Standard",
		"enable_non_ssl_port"             : false,
		"public_network_access_enabled"   : true,
		"minimum_tls_version"             : "1.2",
		"maxmemory_reserved"              : 50,
		"maxmemory_policy"                : "volatile-lru",
		"maxfragmentationmemory_reserved" : 50,
		"enable_rediscache_pep"           : true,
		"rediscache_end_point_name"       : "pep-arc-ads-eus2-entbusops-dev-ihub-001test",
		"enable_rediscache"               : true,
  
	},
  }
  
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
  
	  output := terraform.Output(t, terraformOptions, "redisCacheName")
		assert.Equal(t, "arc-ads-eus2-entbusops-dev-ihub-001test",output)
  
  }
  
func TestServiceBus(t *testing.T) {
  // t.Parallel()
    terraformOptions := &terraform.Options{
      TerraformDir : "./Fixtures/ServiceBus",
       Vars: map[string]interface{}{
        "resource_group_name"                 : "rg-ads-eus2-entbusops-dev-ihub-001",
        "location"                            : "eastus2",
        "service_bus_ns_name"                 : "bus-ads-eus2-entbusops-dev-ihub-001-t",
        "service_bus_ns_sku"                  : "Premium",
        "service_bus_capacity"                : "1",
        "service_bus_end_point_name"          : "pep-bus-ads-eus2-entbusops-dev-ihub-001-t",
        "enable_service_bus_pep"              : "true",
        "data_pep_subnet_name"                : "sn-ads-eus2-entbusops-dev-ihub-pep-001",
        "vnet_name"                           : "vnet-ads-eus2-entbusops-dev-ihub-001",
       },
    }
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)
    output := terraform.Output(t, terraformOptions, "servicebusname")
    assert.Equal(t, "bus-ads-eus2-entbusops-dev-ihub-001-t",output)
}

func TestCosmosDB(t *testing.T) {
  // t.Parallel()
    terraformOptions := &terraform.Options{
      TerraformDir : "./Fixtures/cosmosDB",
       Vars: map[string]interface{}{
         "rgName"                          : "rg-ads-eus2-entbusops-dev-ihub-001",
         "region"                          : "eastus2",
         "create_cosmos"                   : true,
         "cosmosdbaccountname"             : "cdbacc-ads-eus2-entbusops-dev-ihub-001t",
         "offer_type"                      : "Standard",
         "sqldbName"                       : "cdb-ads-eus2-entbusops-dev-ihub-001t",
         "max_throughput"                  : "4000",
         "sqlcontainerName"                : "cdbcon-ads-eus2-entbusops-dev-ihub-001t",
         "partition_key_path"              : "/id",
         "failover_priority"               : 0,
         "enable_free_tier"                : false,
         "zone_redundant"                  : false,
         "consistency_level"               : "Session",
         "failoverpriority"                : 1,
         "failover_location"               : "centralus",
         "enable_multiple_write_locations" : false,
         "cosmosdb_end_point_name"         : "pep-cdb-ads-eus2-entbusops-dev-ihub-001t",
         "backup_type"                     : "Periodic",
         "backup_interval"                 : 240,
         "backup_retention"                : 8,
         "data_pep_subnet_name"             :"sn-ads-eus2-entbusops-dev-ihub-pep-001",
         "vnet_name"                       :"vnet-ads-eus2-entbusops-dev-ihub-001",
         
       },
    }
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)
    
    output1 := terraform.Output(t, terraformOptions, "cosmosdbaccname")
    assert.Equal(t, "cdbacc-ads-eus2-entbusops-dev-ihub-001t", output1)
    output2 := terraform.Output(t, terraformOptions, "cosmosdbname")
    assert.Equal(t, "cdb-ads-eus2-entbusops-dev-ihub-001t", output2)

} 

// MS sql start
func TestMsSql(t *testing.T) {
	// t.Parallel()
  
	  terraformOptions := &terraform.Options{
  
		
		TerraformDir : "./Fixtures/mssql-db",
	  
	   Vars: map[string]interface{}{
	 
      "prim_keyvault_secret_name"     : "ACS26X008ADMIN-PW-Key",
      "sec_keyvault_secret_name"      : "ACS26X008ADMIN-PW-Key",
      "create_primary_server"         : true,
      "primary_sqlserver_name"        : "acs26x008t",
      "primary_sql_location"          : "eastus2",
      "primary_administrator_login"   : "adssqladmin",
      "create_secondary_server"       : false,
      "secondary_sqlserver_name"      : "acs26x008t", 
      "secondary_sql_location"        : "eastus2",
      "secondary_administrator_login" : "adssqladmin",
      "create_primary_db"             : true,
      "primary_sqldb_name"            : "sdb-ads-eus2-entbusops-dev-ihub-customer-001-t",
      "create_secondary_db"           : false,
      "secondary_sqldb_name"          : "sdb-ads-eus2-entbusops-dev-ihub-customer-001-t",
      "create_failover"               : false,
      "failover_name"                 : "fg-ads-cus-entbusops-ihub-enterprise-integration-0002-t",
      "create_sql_pep"                : true,
      "sql_pep_name"                  : "pep-sdb-ads-eus2-entbusops-dev-customer-001-t",
      "pep_sql_location"              : "eastus2",
      "create_sql_pep_eus2"           : false,
      "sql_pep_name_eus2"             : "pep-sdb-ads-eus2-entbusops-dev-customer-001-t",
      "weekly_retention"              : "P8W",
      "monthly_retention"             : "P24M",
      "yearly_retention"              : "P10Y",
      "week_of_year"                  : 1,
      "retention_days"                : 35,
      "ad_login_name"                 : "RET CAD4 SQL Administrators",
      "ad_login_object_id"            : "bec87402-9ea6-4fb6-9028-4ffd0056d26b",
      "public_net_access_enabled"     : false,
      "rgName"                        : "rg-ads-eus2-entbusops-dev-ihub-001",
      "key_vault_name"                : "kvadseus2entbusopsihub1",
      "data_pep_subnet_name"          : "sn-ads-eus2-entbusops-dev-ihub-pep-001",
      "vnet_name"                     : "vnet-ads-eus2-entbusops-dev-ihub-001",
      "sql_server_version"            : "12.0",
      "sql_collation"                 : "SQL_Latin1_General_CP1_CI_AS",
      "storageAccountType"            : "GRS",
      "create_mode"                   : "Secondary",
      "mode"                          : "Manual",
      "sql_subresource_names"         : "sqlServer",
      "sqldb_key_vault_name"          : "kvadseus2entbusopsihub1",
    },
  }
  
	  // At the end of the test, run `terraform destroy` to clean up any resources that were created
	  defer terraform.Destroy(t, terraformOptions)
  
	  // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	  terraform.InitAndApply(t, terraformOptions)
	  
	  output1 := terraform.Output(t, terraformOptions, "primary_db_name")
    assert.Equal(t, "sdb-ads-eus2-entbusops-dev-ihub-customer-001-t",output1)
    
    output2 := terraform.Output(t, terraformOptions, "primary_db_server")
	  assert.Equal(t, "acs26x008t",output2)

}

func TestFunctionAppStorageAcc(t *testing.T) {
  // t.Parallel()

    terraformOptions := &terraform.Options{
      
      TerraformDir : "./Fixtures/FunctionAppStorageAcc",
    
     Vars: map[string]interface{}{
      "functionName"                 : "funcapp-ads-eus2-entbusops-dev-ihub-001t",
      "region"                       : "eastus2",
      "rgName"                       : "rg-ads-eus2-entbusops-dev-ihub-001",
      "linuxfxversion"               : "Java|11",
      "IdentityType"                 : "SystemAssigned",
      "ftpsstate"                    : "AllAllowed",
      "http2_enabled"                : true,
      "OSVersion"                    : "3",
      "IsHttpsOnly"                  : true,
      "osType"                       : "linux",
      "auth_settings"                : true,
      "functionWorkerRuntime"        : "java",
      "EnableAppServiceStorage"      : true,
      "funct_end_point_name"         : "pep-ads-eus2-entbusops-dev-funcapp-001t",
      "website_contentovervnet"      : "1",
      "saName"                       : "stgadseus2entbusopsih02t",
      "saTier"                       : "Standard",
      "saRepType"                    : "LRS",
      "NetworkRuleDefaultAction"     : "Deny",
      "storage_end_point_name"       : "testendpoint",
      "storage_end_point_name_file"  : "pep-sas-file-ads-eus2-entbusops-dev-001t",
      "storage_end_point_name_table" : "pep-sas-table-ads-eus2-entbusops-dev-001t",
      "kvname"                       : "kvadseus2entbusopsihub1",
      "kvrgname"                     : "rg-ads-eus2-entbusops-dev-ihub-001",
      "enable_private_dns_zone_group": false,
    },
}

    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)

    output1 := terraform.Output(t, terraformOptions, "staccname1")
    assert.Equal(t, "stgadseus2entbusopsih02t",output1)
    output2 := terraform.Output(t, terraformOptions, "functionapp_name")
    assert.Equal(t, "funcapp-ads-eus2-entbusops-dev-ihub-001t",output2)
}

func TestEventhub(t *testing.T) {
  // t.Parallel()
    terraformOptions := &terraform.Options{
      TerraformDir : "./Fixtures/Eventhub",
       Vars: map[string]interface{}{
        "namespace_name"                : "evhneus2entbusopsihubdev001-t",
        "create_eventhub_ns"            : "true",
        "location"                      : "eastus2",
        "rgName"                        : "rg-ads-eus2-entbusops-dev-ihub-001",
        "eventhub_sku"                  : "Standard",
        "eventhub_capacity"             : "1",
        "auto_inflate_enabled"          : "true",
        "maximum_throughput_units"      : "20",
        "eventhub_name"                 : "evheus2entbusopsloggingdev001-t",
        "partition_count"               : "1",
        "mess_retention"                : "7",
        "eventhub_ns_pep_name"          : "pep-evhn-ads-eus2-entbusops-dev-001-t",
        "eventhub_ns_subresource_names" : "namespace",
        "eventhub_authrule_name"        : "appsvc-ctx-msging-t",
        "send"                          : "true",
        "listen"                        : "true",
        "manage"                        : "true",
        "data_pep_subnet_name"          : "sn-ads-eus2-entbusops-dev-ihub-pep-001",
        "vnet_name"                     : "vnet-ads-eus2-entbusops-dev-ihub-001",
       },
    }
    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)
    output := terraform.Output(t, terraformOptions, "eventhub_name")
    assert.Equal(t, "evheus2entbusopsloggingdev001-t",output)
    output1 := terraform.Output(t, terraformOptions, "namespace_name")
    assert.Equal(t, "evhneus2entbusopsihubdev001-t",output1)
}

